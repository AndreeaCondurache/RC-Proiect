# Complet
# Compilat
from IPAddr import *
class CampAddr:
    def __init__(self, _ipAddr, _mask):

        self.nrSNetV= [] #numar de subnet
        ip= [] #adresa IP
        negMask= [] #masca negata
        nrSNet=0  #numar de subretele
        self.broadcastAddr="" #adresa de broad cast
        self.net_network=_ipAddr


        for y in _ipAddr.split('.'):
            ip.append(int(y)) # separ ip de puncte si pun in vect ip

        for y in _mask.split('.'):
            negMask.append(255-int(y)) #calculez negatul mastii

        for i in range(0,4):
            if negMask[i]!=0:
                nrSNet+=negMask[i]*pow(2,8*(3-i))

        #construim vectorul cu adresele ip disponibile
        for i in range(1,nrSNet):
            ip[3]+=1
            if ip[3]>255:
                ip[3]=0
                i[2]+=1
                if ip[2]>255:
                    ip[2]=0
                    ip[1]+=1
                    if ip[1]>255:
                        ip[1]=0
                        ip[0]+=1
            self.nrSNetV.append(IPAddr(str(ip[0])+'.'+str(ip[1])+'.'+str(ip[2])+'.'+str(ip[3])))

        #asignarea unei adrese ip unui server
        self.server_identificator=str(ip[0])+'.'+str(ip[1])+'.'+str(ip[2])+'.'+str(ip[3])
        for client_ip in self.nrSNetV:
            if client_ip.ip==self.server_identificator:
                self.nrSNetV.remove(client_ip) #adresa s-a asignat deci o scot din setul de adrese disponibile

        #cautam o adresa de broadcast
        self.BroadcastAddr=str(ip[0])+'.'+str(ip[1])+'.'+str(ip[2])+'.'+str(ip[3]+1)

        #functia de alocare a addr ip
        def getFreeAddr(self, _mac):
            ip=0
            for x in self.nrSNetV:
                if x.liber==1 and x.hold !=1:
                    x.hold_address() #marchez
                    x.setMac(_mac) #setez mac
                    ip=x
                    break
            return ip #returnez ip


        #functie apelata daca clintul doreste aceiasi adddr
        def setAddrLock(self, _mac): #ip rezervat
            for x in self.nrSNetV:
                if x.mac==_mac:
                    x.make_ip_unavailable() #adresa ip este alocata
                    break

        #functie apelata in caz de lease time expira sau clientul trimite mesajul DHCPRELEASE
        def ResetAddrLock(self,_mac): #ip nerezervat
            for x in self.nrSNetV:
                if x.mac==_mac:
                    x.make_ip_available()
                    break

        # functie apelata in caz de adresa ip atribuita initial nu este validata de client
        # si astfel o facem disponibila pentru alte atribuiri
        def setAddrNerezervata(self, _mac):
            for x in self.nrSNetV:
                if x.mac==_mac:
                    x.realease_add()
                    x.setMac("")
                    break
         #functie de cautare a unei addr mac
        def findAddrMAC(self, _mac):
            for x in self.nrSNetV:
                if x.mac==_mac:
                    return x
            return ""
        #functie de cautare pentru addr ip
        def findAddrIp(self,_ip):
            for x in self.nrSNetV:
                if x.ip==_ip:
                    return x
            return ""

        def findOldAddr(self, _oldmac):
            for x in self.nrSNetV:
                if x.oldmac==_oldmac:
                    return x
            return ""
        #urmatoarea functie aloca pentru un client o adresa ip noua in functie de doua criterii 1. a avut initial o adresa ip, s-a cerut una explicit sau se aloca acum una disponibila.
        def aloca_addr_noua_pentru_client(self, mac, options):
            OldIp=self.findOldAddr(options[50])
            if OldIp!="":
                if OldIp.liber==1 and OldIp.hold!=1:  #ip este valid #se ia o adresa de a clintului care a fost deja atribuita
                    OldIp.setMac(mac)
                    OldIp.hold_address()
                    return OldIp.ip
            elif 50 in options: #solicita alta adresa
                requested_ip=self.findAddrIp(options[50])
                if requested_ip!="":
                    if requested_ip==1 and requested_ip==0:
                        requested_ip.setMac(mac)
                        requested_ip.hold_address()
                        return requested_ip.ip
            new_ip=self.getFreeAddr(mac)
            new_ip.setMac(mac)
            new_ip.hold_address()
            return new_ip.ip










