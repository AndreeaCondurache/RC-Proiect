import logging

logger = logging.getLogger("consola_logare")
port_client = 68

class SenderHandle:
    optionSendInDiscovery = {}
    leaseTime = {}
    configurations = {}

    def __init__(self, _conn, _pool, _configurations):
        self.conn = _conn
        self.pool = _pool
        self.configurations = _configurations
        self.dest = ("255.255.255.255", port_client)

    def handle(self, message, clients_display):
        if self.get_type_of_message(message.options) != '':
            message = self.change_message_for_send(self.get_type_of_message(message.options), message, clients_display)
        else:
            logger.critical("Tipul optiunii nu este in mesaj!")
            return 'INVALID'
        return message

    def get_type_of_message(self, options):
        return options[53]

    def change_message_for_send(self, type_of_message, message, clients_display):
        if type_of_message == 'DHCPDISCOVER':
            message.op = '02'
            message.yiaddr = self.pool.get_a_new_ip_for_client(message.chaddr, message.options)
            logger.info("Clientul a luat aceasta adresa ip:" + message.yiaddr + "!")

            if 51 in message.options:
                requested_lease_time = int(message.options[51])
                if 1000 > requested_lease_time > 8000:
                    requested_lease_time = self.configurations[51]
                message.options[51] = requested_lease_time
                self.leaseTime[message.chaddr] = requested_lease_time
            else:
                if message.chaddr in self.leaseTime:
                    message.options[51] = self.leaseTime[message.chaddr]
                else:
                    message.options[51] = self.configurations[51]
            logger.info("Clientul a luat acest lease time:" + str(message.options[51]) + "!")

            # change type of message
            message.options[53] = 'DHCPOFFER'

            # server identifier
            message.options[54] = self.configurations[54]

            # configure the other options
            if 55 in message.options:
                for option in message.options[55]:
                    if option in self.configurations:
                        message.options[option] = self.configurations[option]
            else:
                for i in message.options.keys():
                    if i in self.configurations:
                        message.options[i] = self.configurations[i]

            # remove useless option
            for roption in [option for option in message.options if option not in self.configurations and option != 53 and option != 51 and option != 54]:
                    message.options.pop(roption)

            # save options send for the future use
            self.optionSendInDiscovery[message.chaddr] = message.options
            logger.info(" DHCPOFFER este gata de transmis!")

        elif type_of_message == 'DHCPREQUEST':
            ip_allocated = self.pool.find_ip_after_mac(message.chaddr)
            if ip_allocated != "":
                if 54 in message.options:
                    if ip_allocated.ip == message.options[50] and message.ciaddr == '0.0.0.0':
                        # SELECTING STATE
                        if self.configurations[54] != message.options[54]:
                            logger.info("Mesajul primit este pentru alt server!")
                            ip_allocated.releaseAddress()
                            return 'INVALID'
                        message.op = '02'
                        message.yiaddr = ip_allocated.ip
                        message.options = self.optionSendInDiscovery[message.chaddr]
                        message.options[53] = 'DHCPACK'
                        ip_allocated.make_ip_unavailable()
                        logger.info("DHCPACK pregatit de trimitere!")
                        clients_display.add_client(message.xid, message.chaddr, message.yiaddr)
                    else:
                        logger.error("Selectare stare:Cererea ip din optiuni nu este aceeasi cu cea asignata!")
                        return 'INVALID'
                else:
                    if message.ciaddr == '0.0.0.0':
                        # INIT REBOOT
                        error = "ok"
                        if message.options[50] != ip_allocated.ip:
                            error = "Ip-ul nu se potriveste"
                            logger.info("Init reboot state: Cererea ip nu se potriveste!")

                        if error == "Ip-ul nu se potriveste":
                            message.op = '02'
                            message.yiaddr = '0.0.0.0'
                            message.options.clear()
                            message.options[53] = 'DHCPNAK'
                            message.options[54] = self.configurations[54]
                            message.sname = ''
                            message.siaddr = '0.0.0.0'
                            message.ciaddr = '0.0.0.0'
                            message.file = ''
                            ip_allocated.release_address()
                            logger.info("DHCPNAK este gata de transmis!")
                        else:
                            logger.info("Init Reboot: Totul este in regula!")
                            message = ''

                    elif 50 not in message.options:
                        logger.info("Renewing state: Lease time updated!")
                        self.leaseTime[message.chaddr] = self.configurations[51]
                        message = ''
            else:
                logger.info("Nicio adresa ip gasita in campul de adrese pentru aceasta adresa mac!")
                return 'INVALID'

        elif type_of_message == 'DHCPDECLINE':
            if message.options[54] == self.configurations[54]:
                ip_allocated = self.pool.find_ip_after_mac(message.chaddr)
                ip_allocated.make_ip_available()
                message = 'INVALID'
                logger.info("Adresa IP a fost anulata si inchisa!")

        elif type_of_message == 'DHCPRELEASE':
            ip_allocated = self.pool.find_ip_after_mac(message.chaddr)
            ip_allocated.make_ip_available()
            message = 'INVALID'
            logger.info("Adresa IP a fost anulata si inchisa!")

        elif type_of_message == 'DHCPINFORM':
            ip_allocated = self.pool.find_ip_after_mac(message.chaddr)
            message.op = '02'
            message.yiaddr = ip_allocated.ip
            message.options = self.optionSendInDiscovery[message.chaddr]
            message.options.pop(51)
            message.options[53] = 'DHCPACK'
            logger.info("Mesajul este gata de transmis, clientul va fi informat asupra configuratiei!")
        return message

    def send(self, socket, message):
        if message != '':
            socket.sendto(message.encode(), self.dest)
