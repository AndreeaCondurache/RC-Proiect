from tkinter import Tk

import gui
from gui import DHCP_gui

if __name__ == '__main__':
    root = Tk()
    root.geometry("1080x650")
    root.resizable(0, 0)

    server = gui.DHCP_gui(root)
    root.mainloop()
