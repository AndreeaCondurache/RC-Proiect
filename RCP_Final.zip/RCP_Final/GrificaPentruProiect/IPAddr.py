# Complet
# Compilat
class IPAddr():
    def __init__(self,_ip):
        self.ip=_ip
        self.mac=""
        self.oldmac=""
        self.leaseT=5000 #timpul de inchiriere
        self.liber=1
        self.hold=0;
        self.options={}
    def setMac(self,_mac):
        self.mac=_mac
    def make_ip_unavailable(self):
        self.hold=0
        self.liber=0
    def hold_address(self):
        self.hold=1
    def realease_add(self):
        self.hold=0
    def make_ip_available(self):
        self.liber=1
        self.hold=0
        self.oldmac=self.mac



