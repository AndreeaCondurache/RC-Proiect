import threading
from tkinter import PhotoImage
from CampAddr import *
from socket import *
from SenderHandle import *
from threading import *
from tkinter import *
from tkinter import scrolledtext
import queue
# DEMO
# window=Tk()
# window.geometry("300x300")
# window.title("Window")
# labell=Label(window,text="Welcome to tk",fg='blue', bg='yellow',relief="solid",font=("arial",16,"bold")).pack()
# labell=Label(window,text="Welcome to tk",fg='blue', bg='yellow',relief="solid",font=("arial",16,"bold")).place(x=110,y=110)
# labell=Label(window,text="Welcome to tk",fg='blue', bg='yellow',relief="solid",font=("arial",16,"bold"))
# labell.pack(fill=BOTH,pady=2,padx=2,expand=True)
# labell.grid(row=1,column=1)
# labell.pack()
# button1=Button(window,text="Demo",fg='white', bg='brown',relief="ridge",font=("arial",16,"bold")) #raised
# button1.place(x=110,y=110)
from client import ClientsPanel

optiuni = {1: "Subnet Mask:",
           3: "Router option",
           6: "Domain Name Server Option:",
           15: "Domain Name",
           58: "Renewal Time Value:"
           }


class DHCP_gui():
    optiuni_valide = [1, 3, 6, 15, 28, 58]

    def __init__(self, _master):
        self.master = _master
        self.initWindow

        # creez o coada de masaje pentru a simula trimiterea acestora
        #self.log_queue = queue.Queue()
        #self.queue_handler = QueueHandler(self.log_queue)
        #formatter = logging.Formatter('%(asctime)s: %(message)s')
        #self.queue_handler.setFormatter(formatter)
        #logger.addHandler(self.queue_handler)

        # Start polling messages from the queue
        #self.master.after(100, self.poll_log_queue)

    @property
    def initWindow(self):
        self.master.title("DHCP SERVER")
#        photo = PhotoImage(file="bg.png")
#        self.master.background = photo;
        pool_config_label_frame = LabelFrame(self.master, text="Pool and lease time config:", width=50, height=50)
        pool_config_label_frame.grid(row=0, column=1, sticky=(N, E, W, S), ipadx=10, ipady=10, padx=5, pady=5)
        pool_config_label_frame.config(bg="#80d4ff")

        # frame-ul unde se afla logul
        log_frame = LabelFrame(self.master, text="Activity log")
        log_frame.grid(row=1, column=2, sticky=(N, E, W, S), ipadx=10, ipady=10, padx=5, pady=5)
        log_frame.config(bg="#80d4ff")
        # Console for the log
        self.scrolled_text = scrolledtext.ScrolledText(log_frame, state='disabled', width=80, height=22)
        self.scrolled_text.grid(row=0, column=0, padx=10, pady=10)
        self.scrolled_text.configure(font='TkFixedFont')
        self.scrolled_text.tag_config('INFO', foreground='black')
        self.scrolled_text.tag_config('DEBUG', foreground='black')
        self.scrolled_text.tag_config('WARNING', foreground='orange')
        self.scrolled_text.tag_config('ERROR', foreground='red')
        self.scrolled_text.tag_config('CRITICAL', foreground='red', underline=1)

        # input network addr
        label2 = Label(pool_config_label_frame, text="Adresa retea:", font="Arial")
        label2.grid(row=0, column=0, padx=3, pady=10)

        self.addr = Entry(pool_config_label_frame, width=25)
        self.addr.grid(row=0, column=1)
        self.addr.insert(0, "192.168.0.0")

        # Input mask address
        label3 = Label(pool_config_label_frame, text="Mask:", font="Arial")
        label3.grid(row=1, column=0, padx=3, pady=10)

        self.mask = Entry(pool_config_label_frame, width=25)
        self.mask.grid(row=1, column=1)
        self.mask.insert(0, "255.255.255.0")

        # Lease time input
        label4 = Label(pool_config_label_frame, text="Lease Time:", font="Arial")
        label4.grid(row=2, column=0, padx=3, pady=10)

        self.leaseTime = Entry(pool_config_label_frame, width=25)
        self.leaseTime.grid(row=2, column=1)
        self.leaseTime.insert(0, "1000")

        # frame-ul unde se afla optiunile
        option_frame = LabelFrame(self.master, width=50, height=50, text="Select options:")
        option_frame.grid(row=1, column=1, sticky=(N, E, W, S), ipadx=10, ipady=10, padx=5, pady=5)
        option_frame.config(bg="#80d4ff")

        # check buttons
        self.values_for_options = {}
        self.checkbuttons = []
        i = 0
        for option in self.optiuni_valide:
            val = IntVar()
            chk = Checkbutton(option_frame, text="Option " + str(option), variable=val)
            chk.grid(row=i, column=0, pady=5)
            self.checkbuttons.append(chk)
            self.values_for_options[option] = val
            i += 1

        # entry for Options
        self.entryOfOptions = {}
        for option in self.optiuni_valide:
            if option != 28:
                Label(option_frame, text="(" + str(option) + ")" + optiuni[option]).grid(row=i, column=0,
                                                                                         sticky=W, pady=5)
                ent = Entry(option_frame, width=25)
                ent.grid(row=i, column=1, pady=5)
                self.entryOfOptions[option] = ent
                i += 1

        # space for show clients
        self.clients_frame = ClientsPanel(self.master, 50, 50, 0, 2, "Clients")
        self.clients_frame.grid(sticky=(N, E, W, S), ipadx=10, ipady=10, padx=5, pady=5)

        comand_buttons = Frame(self.master)
        comand_buttons.grid(row=3, column=1, columnspan=2, ipadx=10, ipady=10, padx=5, pady=5)

        # Quit Button Config
        self.quitButton = Button(comand_buttons, text="Quit", width=30)
       # self.quitButton = Button(comand_buttons, text="Quit", command=self.exitServer, width=30)
        self.quitButton.grid(column=1, row=0, padx=30)

        # Start button Config
        self.startButton = Button(comand_buttons, text="Start", width=30)
       # self.startButton = Button(comand_buttons, text="Start", command=self.start_server, width=30)
        self.startButton.grid(column=0, row=0, padx=30)

